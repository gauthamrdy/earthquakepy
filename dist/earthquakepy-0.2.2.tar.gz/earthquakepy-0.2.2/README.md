# earthquakepy

A python library for earthquake engineers and seismologists.

Read the documentation at [Read the docs](https://earthquakepy.readthedocs.io)
